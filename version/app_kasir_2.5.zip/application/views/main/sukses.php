<div class="container-fluid" id="container-wrapper">
     <div class="row">
         <div class="col-md-12">
<div class="alert alert-success alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span></button>Data berhasil disimpan</div>
<?php
// redirect('main/user','refresh');
?>
 </div>
 </div>
 </div>
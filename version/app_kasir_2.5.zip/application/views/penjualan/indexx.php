<?php
	echo $echo;
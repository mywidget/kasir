<input type="hidden" name="kode_invoice" id="kode_invoice" value="<?=$detail['invoice'];?>">
<input type="hidden" name="kode" id="kode" value="<?=$detail['idr'];?>">
<input class="form-control" type="text" name="finishing" id="finishing" value="<?=$detail['finishing'];?>">
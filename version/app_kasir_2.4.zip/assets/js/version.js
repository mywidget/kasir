var version = document.getElementById('version-ruangadmin');

function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
		}
	}
    rawFile.send(null);
}


window.addEventListener('online', () => console.log('Became online'));
window.addEventListener('offline', () => console.log('Became offline'));
if(navigator.onLine){
	readTextFile("https://mywidget.github.io/version.json", function(text){
		var data = JSON.parse(text);
console.log(data);
		var name = data['aplikasi'][0]['product'];
		var versi = data['aplikasi'][0]['version'];
		version.innerHTML = name + " Version " +versi;
		// localStorage.setItem("versi", versi); 
	});
	} else {
	readTextFile(base_url+"version.json", function(text){
		var data = JSON.parse(text);
		var name = data['aplikasi'][0]['product'];
		var versi = data['aplikasi'][0]['version'];
		version.innerHTML = name + " Version " +versi;
	});
}